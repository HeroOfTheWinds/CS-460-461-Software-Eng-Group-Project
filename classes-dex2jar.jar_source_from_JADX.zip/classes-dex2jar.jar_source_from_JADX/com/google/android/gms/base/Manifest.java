package com.google.android.gms.base;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.nianticlabs.pokemongo.permission.C2D_MESSAGE";
    }
}
