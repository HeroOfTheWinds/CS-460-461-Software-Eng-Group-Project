package com.google.android.gms.internal;

import java.io.IOException;

interface zzaq {
    void reset();

    byte[] zzac() throws IOException;

    void zzb(int i, long j) throws IOException;

    void zzb(int i, String str) throws IOException;
}
