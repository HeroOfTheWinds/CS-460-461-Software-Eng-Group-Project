package com.google.android.gms.internal;

public class zzgs {
    public final zzho zzFt;
    public final zzbt zzFu;
    public final zzea zzFv;
    public final zzfn zzFw;
    public final zzhr zzFx;
    public final zzhb zzFy;
    public final zzha zzFz;

    zzgs(zzho com_google_android_gms_internal_zzho, zzbt com_google_android_gms_internal_zzbt, zzea com_google_android_gms_internal_zzea, zzfn com_google_android_gms_internal_zzfn, zzhr com_google_android_gms_internal_zzhr, zzhb com_google_android_gms_internal_zzhb, zzha com_google_android_gms_internal_zzha) {
        this.zzFt = com_google_android_gms_internal_zzho;
        this.zzFu = com_google_android_gms_internal_zzbt;
        this.zzFv = com_google_android_gms_internal_zzea;
        this.zzFw = com_google_android_gms_internal_zzfn;
        this.zzFx = com_google_android_gms_internal_zzhr;
        this.zzFy = com_google_android_gms_internal_zzhb;
        this.zzFz = com_google_android_gms_internal_zzha;
    }

    public static zzgs zzfQ() {
        return new zzgs(new zzhp(), new zzbs(), new zzeb(), new zzfm(), new zzhq(), new zzhd(), new zzhc());
    }
}
