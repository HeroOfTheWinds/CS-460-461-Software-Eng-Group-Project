package com.google.android.gms.internal;

import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;

public class zziu {
    public static void zza(View view, OnGlobalLayoutListener onGlobalLayoutListener) {
        new zziv(view, onGlobalLayoutListener).zzgW();
    }

    public static void zza(View view, OnScrollChangedListener onScrollChangedListener) {
        new zziw(view, onScrollChangedListener).zzgW();
    }
}
