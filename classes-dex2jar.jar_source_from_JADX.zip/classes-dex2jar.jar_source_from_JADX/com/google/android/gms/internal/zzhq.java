package com.google.android.gms.internal;

@zzgr
public final class zzhq implements zzhr {
    public String zzax(String str) {
        return str;
    }
}
