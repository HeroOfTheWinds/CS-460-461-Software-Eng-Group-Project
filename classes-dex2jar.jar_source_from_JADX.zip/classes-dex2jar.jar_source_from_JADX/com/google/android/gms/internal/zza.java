package com.google.android.gms.internal;

import android.content.Intent;

public class zza extends zzr {
    private Intent zza;

    public zza(zzi com_google_android_gms_internal_zzi) {
        super(com_google_android_gms_internal_zzi);
    }

    public String getMessage() {
        return this.zza != null ? "User needs to (re)enter credentials." : super.getMessage();
    }
}
