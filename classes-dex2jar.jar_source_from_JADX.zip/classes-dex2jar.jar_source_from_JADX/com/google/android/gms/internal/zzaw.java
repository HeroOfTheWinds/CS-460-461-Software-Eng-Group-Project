package com.google.android.gms.internal;

public interface zzaw {
    void zza(zzaz com_google_android_gms_internal_zzaz, boolean z);
}
