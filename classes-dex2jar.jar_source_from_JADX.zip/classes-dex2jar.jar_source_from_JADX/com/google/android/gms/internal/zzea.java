package com.google.android.gms.internal;

import android.location.Location;

public interface zzea {
    void init();

    Location zzd(long j);
}
