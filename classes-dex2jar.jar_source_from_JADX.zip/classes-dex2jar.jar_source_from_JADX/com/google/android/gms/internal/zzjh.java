package com.google.android.gms.internal;

import android.view.View;
import android.webkit.WebChromeClient.CustomViewCallback;

@zzgr
public final class zzjh extends zzjf {
    public zzjh(zziz com_google_android_gms_internal_zziz) {
        super(com_google_android_gms_internal_zziz);
    }

    public void onShowCustomView(View view, int i, CustomViewCallback customViewCallback) {
        zza(view, i, customViewCallback);
    }
}
