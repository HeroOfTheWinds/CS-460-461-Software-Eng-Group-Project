package com.google.android.gms.internal;

@zzgr
public class zzje {
    private final zziz zzoM;

    public zzje(zziz com_google_android_gms_internal_zziz) {
        this.zzoM = com_google_android_gms_internal_zziz;
    }
}
