package com.google.android.gms.internal;

public interface zzis<T> {

    public interface zzc<T> {
        void zzc(T t);
    }

    public interface zza {
        void run();
    }

    public static class zzb implements zza {
        public void run() {
        }
    }
}
