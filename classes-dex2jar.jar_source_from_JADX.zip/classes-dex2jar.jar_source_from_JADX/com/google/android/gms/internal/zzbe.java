package com.google.android.gms.internal;

import org.json.JSONObject;

public interface zzbe {
    void zza(String str, zzdk com_google_android_gms_internal_zzdk);

    void zza(String str, String str2);

    void zza(String str, JSONObject jSONObject);

    void zzb(String str, zzdk com_google_android_gms_internal_zzdk);

    void zzb(String str, JSONObject jSONObject);
}
