package com.google.android.gms.internal;

import java.util.List;

public interface zzec {
    void cancel();

    zzei zzc(List<zzed> list);
}
