package com.google.android.gms.internal;

import android.content.Context;

public interface zzhb {

    public static class zza {
        public final int zzGS;
        public final long zzGT;
        public final long zzGU;
    }

    zza zzD(Context context);
}
