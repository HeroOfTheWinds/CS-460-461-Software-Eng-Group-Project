package rx.observables;

import java.util.concurrent.atomic.AtomicLong;
import rx.Observable.OnSubscribe;
import rx.Observer;
import rx.Producer;
import rx.Subscriber;
import rx.Subscription;
import rx.annotations.Beta;
import rx.exceptions.Exceptions;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Action2;
import rx.functions.Func0;
import rx.functions.Func2;
import rx.internal.operators.BackpressureUtils;
import rx.plugins.RxJavaPlugins;

@Beta
public abstract class SyncOnSubscribe<S, T> implements OnSubscribe<T> {

    /* renamed from: rx.observables.SyncOnSubscribe.1 */
    static final class C14791 implements Func2<S, Observer<? super T>, S> {
        final /* synthetic */ Action2 val$next;

        C14791(Action2 action2) {
            this.val$next = action2;
        }

        public S call(S s, Observer<? super T> observer) {
            this.val$next.call(s, observer);
            return s;
        }
    }

    /* renamed from: rx.observables.SyncOnSubscribe.2 */
    static final class C14802 implements Func2<S, Observer<? super T>, S> {
        final /* synthetic */ Action2 val$next;

        C14802(Action2 action2) {
            this.val$next = action2;
        }

        public S call(S s, Observer<? super T> observer) {
            this.val$next.call(s, observer);
            return s;
        }
    }

    /* renamed from: rx.observables.SyncOnSubscribe.3 */
    static final class C14813 implements Func2<Void, Observer<? super T>, Void> {
        final /* synthetic */ Action1 val$next;

        C14813(Action1 action1) {
            this.val$next = action1;
        }

        public Void call(Void voidR, Observer<? super T> observer) {
            this.val$next.call(observer);
            return voidR;
        }
    }

    /* renamed from: rx.observables.SyncOnSubscribe.4 */
    static final class C14824 implements Func2<Void, Observer<? super T>, Void> {
        final /* synthetic */ Action1 val$next;

        C14824(Action1 action1) {
            this.val$next = action1;
        }

        public Void call(Void voidR, Observer<? super T> observer) {
            this.val$next.call(observer);
            return null;
        }
    }

    /* renamed from: rx.observables.SyncOnSubscribe.5 */
    static final class C14835 implements Action1<Void> {
        final /* synthetic */ Action0 val$onUnsubscribe;

        C14835(Action0 action0) {
            this.val$onUnsubscribe = action0;
        }

        public void call(Void voidR) {
            this.val$onUnsubscribe.call();
        }
    }

    private static class SubscriptionProducer<S, T> extends AtomicLong implements Producer, Subscription, Observer<T> {
        private static final long serialVersionUID = -3736864024352728072L;
        private final Subscriber<? super T> actualSubscriber;
        private boolean hasTerminated;
        private boolean onNextCalled;
        private final SyncOnSubscribe<S, T> parent;
        private S state;

        SubscriptionProducer(Subscriber<? super T> subscriber, SyncOnSubscribe<S, T> syncOnSubscribe, S s) {
            this.actualSubscriber = subscriber;
            this.parent = syncOnSubscribe;
            this.state = s;
        }

        private void doUnsubscribe() {
            try {
                this.parent.onUnsubscribe(this.state);
            } catch (Throwable th) {
                Exceptions.throwIfFatal(th);
                RxJavaPlugins.getInstance().getErrorHandler().handleError(th);
            }
        }

        private void fastpath() {
            SyncOnSubscribe syncOnSubscribe = this.parent;
            Subscriber subscriber = this.actualSubscriber;
            do {
                try {
                    this.onNextCalled = false;
                    nextIteration(syncOnSubscribe);
                } catch (Throwable th) {
                    handleThrownError(subscriber, th);
                    return;
                }
            } while (!tryUnsubscribe());
        }

        private void handleThrownError(Subscriber<? super T> subscriber, Throwable th) {
            if (this.hasTerminated) {
                RxJavaPlugins.getInstance().getErrorHandler().handleError(th);
                return;
            }
            this.hasTerminated = true;
            subscriber.onError(th);
            unsubscribe();
        }

        private void nextIteration(SyncOnSubscribe<S, T> syncOnSubscribe) {
            this.state = syncOnSubscribe.next(this.state, this);
        }

        private void slowPath(long j) {
            SyncOnSubscribe syncOnSubscribe = this.parent;
            Subscriber subscriber = this.actualSubscriber;
            do {
                long j2 = j;
                do {
                    try {
                        this.onNextCalled = false;
                        nextIteration(syncOnSubscribe);
                        if (!tryUnsubscribe()) {
                            if (this.onNextCalled) {
                                j2--;
                            }
                        } else {
                            return;
                        }
                    } catch (Throwable th) {
                        handleThrownError(subscriber, th);
                        return;
                    }
                } while (j2 != 0);
                j = addAndGet(-j);
            } while (j > 0);
            tryUnsubscribe();
        }

        private boolean tryUnsubscribe() {
            if (!this.hasTerminated && get() >= -1) {
                return false;
            }
            set(-1);
            doUnsubscribe();
            return true;
        }

        public boolean isUnsubscribed() {
            return get() < 0;
        }

        public void onCompleted() {
            if (this.hasTerminated) {
                throw new IllegalStateException("Terminal event already emitted.");
            }
            this.hasTerminated = true;
            if (!this.actualSubscriber.isUnsubscribed()) {
                this.actualSubscriber.onCompleted();
            }
        }

        public void onError(Throwable th) {
            if (this.hasTerminated) {
                throw new IllegalStateException("Terminal event already emitted.");
            }
            this.hasTerminated = true;
            if (!this.actualSubscriber.isUnsubscribed()) {
                this.actualSubscriber.onError(th);
            }
        }

        public void onNext(T t) {
            if (this.onNextCalled) {
                throw new IllegalStateException("onNext called multiple times!");
            }
            this.onNextCalled = true;
            this.actualSubscriber.onNext(t);
        }

        public void request(long j) {
            if (j > 0 && BackpressureUtils.getAndAddRequest(this, j) == 0) {
                if (j == Long.MAX_VALUE) {
                    fastpath();
                } else {
                    slowPath(j);
                }
            }
        }

        public void unsubscribe() {
            long j;
            do {
                j = get();
                if (compareAndSet(0, -1)) {
                    doUnsubscribe();
                    return;
                }
            } while (!compareAndSet(j, -2));
        }
    }

    private static final class SyncOnSubscribeImpl<S, T> extends SyncOnSubscribe<S, T> {
        private final Func0<? extends S> generator;
        private final Func2<? super S, ? super Observer<? super T>, ? extends S> next;
        private final Action1<? super S> onUnsubscribe;

        public SyncOnSubscribeImpl(Func0<? extends S> func0, Func2<? super S, ? super Observer<? super T>, ? extends S> func2) {
            this(func0, func2, null);
        }

        SyncOnSubscribeImpl(Func0<? extends S> func0, Func2<? super S, ? super Observer<? super T>, ? extends S> func2, Action1<? super S> action1) {
            this.generator = func0;
            this.next = func2;
            this.onUnsubscribe = action1;
        }

        public SyncOnSubscribeImpl(Func2<S, Observer<? super T>, S> func2) {
            this(null, func2, null);
        }

        public SyncOnSubscribeImpl(Func2<S, Observer<? super T>, S> func2, Action1<? super S> action1) {
            this(null, func2, action1);
        }

        public /* bridge */ /* synthetic */ void call(Object obj) {
            super.call((Subscriber) obj);
        }

        protected S generateState() {
            return this.generator == null ? null : this.generator.call();
        }

        protected S next(S s, Observer<? super T> observer) {
            return this.next.call(s, observer);
        }

        protected void onUnsubscribe(S s) {
            if (this.onUnsubscribe != null) {
                this.onUnsubscribe.call(s);
            }
        }
    }

    @Beta
    public static <S, T> SyncOnSubscribe<S, T> createSingleState(Func0<? extends S> func0, Action2<? super S, ? super Observer<? super T>> action2) {
        return new SyncOnSubscribeImpl((Func0) func0, new C14791(action2));
    }

    @Beta
    public static <S, T> SyncOnSubscribe<S, T> createSingleState(Func0<? extends S> func0, Action2<? super S, ? super Observer<? super T>> action2, Action1<? super S> action1) {
        return new SyncOnSubscribeImpl(func0, new C14802(action2), action1);
    }

    @Beta
    public static <S, T> SyncOnSubscribe<S, T> createStateful(Func0<? extends S> func0, Func2<? super S, ? super Observer<? super T>, ? extends S> func2) {
        return new SyncOnSubscribeImpl((Func0) func0, (Func2) func2);
    }

    @Beta
    public static <S, T> SyncOnSubscribe<S, T> createStateful(Func0<? extends S> func0, Func2<? super S, ? super Observer<? super T>, ? extends S> func2, Action1<? super S> action1) {
        return new SyncOnSubscribeImpl(func0, func2, action1);
    }

    @Beta
    public static <T> SyncOnSubscribe<Void, T> createStateless(Action1<? super Observer<? super T>> action1) {
        return new SyncOnSubscribeImpl(new C14813(action1));
    }

    @Beta
    public static <T> SyncOnSubscribe<Void, T> createStateless(Action1<? super Observer<? super T>> action1, Action0 action0) {
        return new SyncOnSubscribeImpl(new C14824(action1), new C14835(action0));
    }

    public final void call(Subscriber<? super T> subscriber) {
        try {
            Object subscriptionProducer = new SubscriptionProducer(subscriber, this, generateState());
            subscriber.add(subscriptionProducer);
            subscriber.setProducer(subscriptionProducer);
        } catch (Throwable th) {
            Exceptions.throwIfFatal(th);
            subscriber.onError(th);
        }
    }

    protected abstract S generateState();

    protected abstract S next(S s, Observer<? super T> observer);

    protected void onUnsubscribe(S s) {
    }
}
