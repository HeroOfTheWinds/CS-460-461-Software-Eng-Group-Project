package rx.functions;

public interface Action extends Function {
}
