package rx.functions;

public interface ActionN extends Action {
    void call(Object... objArr);
}
