package rx.android;

import spacemadness.com.lunarconsole.C1518R;

/* renamed from: rx.android.R */
public final class C1241R {

    /* renamed from: rx.android.R.anim */
    public static final class anim {
        public static final int lunar_console_slide_in_top = 2130968576;
        public static final int lunar_console_slide_out_top = 2130968577;
    }

    /* renamed from: rx.android.R.attr */
    public static final class attr {
        public static final int adSize = 2130771971;
        public static final int adSizes = 2130771972;
        public static final int adUnitId = 2130771973;
        public static final int circleCrop = 2130771970;
        public static final int imageAspectRatio = 2130771969;
        public static final int imageAspectRatioAdjust = 2130771968;
    }

    /* renamed from: rx.android.R.color */
    public static final class color {
        public static final int common_action_bar_splitter = 2131230729;
        public static final int common_signin_btn_dark_text_default = 2131230720;
        public static final int common_signin_btn_dark_text_disabled = 2131230722;
        public static final int common_signin_btn_dark_text_focused = 2131230723;
        public static final int common_signin_btn_dark_text_pressed = 2131230721;
        public static final int common_signin_btn_default_background = 2131230728;
        public static final int common_signin_btn_light_text_default = 2131230724;
        public static final int common_signin_btn_light_text_disabled = 2131230726;
        public static final int common_signin_btn_light_text_focused = 2131230727;
        public static final int common_signin_btn_light_text_pressed = 2131230725;
        public static final int common_signin_btn_text_dark = 2131230747;
        public static final int common_signin_btn_text_light = 2131230748;
        public static final int lunar_console_color_cell_background_dark = 2131230733;
        public static final int lunar_console_color_cell_background_light = 2131230734;
        public static final int lunar_console_color_cell_text = 2131230735;
        public static final int lunar_console_color_cell_text_location = 2131230736;
        public static final int lunar_console_color_exception_bar_background = 2131230737;
        public static final int lunar_console_color_exception_bar_text = 2131230738;
        public static final int lunar_console_color_fake_status_bar = 2131230739;
        public static final int lunar_console_color_fake_status_bar_text = 2131230740;
        public static final int lunar_console_color_log_button_background = 2131230741;
        public static final int lunar_console_color_log_button_selected_background = 2131230742;
        public static final int lunar_console_color_table_background = 2131230743;
        public static final int lunar_console_color_table_title_background = 2131230744;
        public static final int lunar_console_color_warning_background = 2131230745;
        public static final int lunar_console_color_warning_text = 2131230746;
        public static final int np_semi_transparent = 2131230732;
        public static final int np_topbar_color = 2131230730;
        public static final int np_transparent = 2131230731;
    }

    /* renamed from: rx.android.R.dimen */
    public static final class dimen {
        public static final int activity_horizontal_margin = 2131427328;
        public static final int activity_vertical_margin = 2131427329;
        public static final int lunar_layout_console_entry_margin = 2131427330;
        public static final int lunar_layout_console_stacktrace_margin = 2131427331;
    }

    /* renamed from: rx.android.R.drawable */
    public static final class drawable {
        public static final int app_banner = 2130837504;
        public static final int app_icon = 2130837505;
        public static final int app_icon_custom_coloured = 2130837506;
        public static final int app_icon_custom_white = 2130837507;
        public static final int common_full_open_on_phone = 2130837508;
        public static final int common_ic_googleplayservices = 2130837509;
        public static final int common_signin_btn_icon_dark = 2130837510;
        public static final int common_signin_btn_icon_disabled_dark = 2130837511;
        public static final int common_signin_btn_icon_disabled_focus_dark = 2130837512;
        public static final int common_signin_btn_icon_disabled_focus_light = 2130837513;
        public static final int common_signin_btn_icon_disabled_light = 2130837514;
        public static final int common_signin_btn_icon_focus_dark = 2130837515;
        public static final int common_signin_btn_icon_focus_light = 2130837516;
        public static final int common_signin_btn_icon_light = 2130837517;
        public static final int common_signin_btn_icon_normal_dark = 2130837518;
        public static final int common_signin_btn_icon_normal_light = 2130837519;
        public static final int common_signin_btn_icon_pressed_dark = 2130837520;
        public static final int common_signin_btn_icon_pressed_light = 2130837521;
        public static final int common_signin_btn_text_dark = 2130837522;
        public static final int common_signin_btn_text_disabled_dark = 2130837523;
        public static final int common_signin_btn_text_disabled_focus_dark = 2130837524;
        public static final int common_signin_btn_text_disabled_focus_light = 2130837525;
        public static final int common_signin_btn_text_disabled_light = 2130837526;
        public static final int common_signin_btn_text_focus_dark = 2130837527;
        public static final int common_signin_btn_text_focus_light = 2130837528;
        public static final int common_signin_btn_text_light = 2130837529;
        public static final int common_signin_btn_text_normal_dark = 2130837530;
        public static final int common_signin_btn_text_normal_light = 2130837531;
        public static final int common_signin_btn_text_pressed_dark = 2130837532;
        public static final int common_signin_btn_text_pressed_light = 2130837533;
        public static final int ic_launcher = 2130837534;
        public static final int lunar_console_icon_button_clear = 2130837535;
        public static final int lunar_console_icon_button_clipboard = 2130837536;
        public static final int lunar_console_icon_button_close = 2130837537;
        public static final int lunar_console_icon_button_console = 2130837538;
        public static final int lunar_console_icon_button_email = 2130837539;
        public static final int lunar_console_icon_button_lock = 2130837540;
        public static final int lunar_console_icon_button_unlock = 2130837541;
        public static final int lunar_console_icon_log = 2130837542;
        public static final int lunar_console_icon_log_error = 2130837543;
        public static final int lunar_console_icon_log_warning = 2130837544;
        public static final int lunar_console_shape_edit_text = 2130837545;
        public static final int np_webview_back_button_normal = 2130837546;
        public static final int np_webview_close_button_normal = 2130837547;
        public static final int np_webview_forward_button_normal = 2130837548;
        public static final int np_webview_reload_button_normal = 2130837549;
        public static final int powered_by_google_dark = 2130837550;
        public static final int powered_by_google_light = 2130837551;
    }

    /* renamed from: rx.android.R.id */
    public static final class id {
        public static final int adjust_height = 2131492864;
        public static final int adjust_width = 2131492865;
        public static final int lunar_console_button_clear = 2131492875;
        public static final int lunar_console_button_close = 2131492879;
        public static final int lunar_console_button_copy = 2131492877;
        public static final int lunar_console_button_details = 2131492887;
        public static final int lunar_console_button_dismiss = 2131492888;
        public static final int lunar_console_button_email = 2131492878;
        public static final int lunar_console_button_lock = 2131492876;
        public static final int lunar_console_error_button = 2131492872;
        public static final int lunar_console_fake_status_bar = 2131492868;
        public static final int lunar_console_log_button = 2131492870;
        public static final int lunar_console_log_details_icon = 2131492883;
        public static final int lunar_console_log_details_message = 2131492884;
        public static final int lunar_console_log_details_stacktrace = 2131492885;
        public static final int lunar_console_log_entry_icon = 2131492881;
        public static final int lunar_console_log_entry_layout = 2131492880;
        public static final int lunar_console_log_entry_message = 2131492882;
        public static final int lunar_console_recycler_view_container = 2131492873;
        public static final int lunar_console_text_edit_filter = 2131492869;
        public static final int lunar_console_text_overflow = 2131492874;
        public static final int lunar_console_text_warning_message = 2131492886;
        public static final int lunar_console_warning_button = 2131492871;
        public static final int none = 2131492866;
        public static final int np_progressbar_bottom_spacer = 2131492892;
        public static final int np_progressbar_root = 2131492889;
        public static final int np_progressbar_spinner = 2131492891;
        public static final int np_toolbar_back = 2131492895;
        public static final int np_toolbar_close = 2131492898;
        public static final int np_toolbar_forward = 2131492896;
        public static final int np_toolbar_reload = 2131492897;
        public static final int np_toolbar_top_spacer = 2131492890;
        public static final int np_topbar_layout = 2131492894;
        public static final int np_webview = 2131492900;
        public static final int np_webview_closebutton = 2131492901;
        public static final int np_webview_frameLayout = 2131492899;
        public static final int np_webview_root_layout = 2131492893;
        public static final int spinner = 2131492867;
        public static final int upsight_marketing_content_view_close_button = 2131492903;
        public static final int upsight_marketing_content_view_web_view = 2131492902;
    }

    /* renamed from: rx.android.R.integer */
    public static final class integer {
        public static final int google_play_services_version = 2131296256;
    }

    /* renamed from: rx.android.R.layout */
    public static final class layout {
        public static final int accounts_activity = 2130903040;
        public static final int lunar_layout_console = 2130903041;
        public static final int lunar_layout_console_log_entry = 2130903042;
        public static final int lunar_layout_log_details_dialog = 2130903043;
        public static final int lunar_layout_warning = 2130903044;
        public static final int np_progressbar_layout = 2130903045;
        public static final int np_webview_layout = 2130903046;
        public static final int upsight_activity_billboard_management = 2130903047;
        public static final int upsight_fragment_billboard = 2130903048;
        public static final int upsight_marketing_content_view = 2130903049;
    }

    /* renamed from: rx.android.R.raw */
    public static final class raw {
        public static final int configurator_config = 2131099648;
        public static final int dispatcher_config = 2131099649;
        public static final int push_config = 2131099650;
        public static final int uxm_schema = 2131099651;
    }

    /* renamed from: rx.android.R.string */
    public static final class string {
        public static final int Loading = 2131165226;
        public static final int accept = 2131165220;
        public static final int action_settings = 2131165236;
        public static final int app_name = 2131165224;
        public static final int auth_google_play_services_client_facebook_display_name = 2131165185;
        public static final int auth_google_play_services_client_google_display_name = 2131165184;
        public static final int com_crashlytics_android_build_id = 2131165225;
        public static final int common_android_wear_notification_needs_update_text = 2131165188;
        public static final int common_android_wear_update_text = 2131165201;
        public static final int common_android_wear_update_title = 2131165199;
        public static final int common_google_play_services_api_unavailable_text = 2131165213;
        public static final int common_google_play_services_enable_button = 2131165197;
        public static final int common_google_play_services_enable_text = 2131165196;
        public static final int common_google_play_services_enable_title = 2131165195;
        public static final int common_google_play_services_error_notification_requested_by_msg = 2131165190;
        public static final int common_google_play_services_install_button = 2131165194;
        public static final int common_google_play_services_install_text_phone = 2131165192;
        public static final int common_google_play_services_install_text_tablet = 2131165193;
        public static final int common_google_play_services_install_title = 2131165191;
        public static final int common_google_play_services_invalid_account_text = 2131165207;
        public static final int common_google_play_services_invalid_account_title = 2131165206;
        public static final int common_google_play_services_needs_enabling_title = 2131165189;
        public static final int common_google_play_services_network_error_text = 2131165205;
        public static final int common_google_play_services_network_error_title = 2131165204;
        public static final int common_google_play_services_notification_needs_update_title = 2131165187;
        public static final int common_google_play_services_notification_ticker = 2131165186;
        public static final int common_google_play_services_sign_in_failed_text = 2131165215;
        public static final int common_google_play_services_sign_in_failed_title = 2131165214;
        public static final int common_google_play_services_unknown_issue = 2131165208;
        public static final int common_google_play_services_unsupported_text = 2131165210;
        public static final int common_google_play_services_unsupported_title = 2131165209;
        public static final int common_google_play_services_update_button = 2131165211;
        public static final int common_google_play_services_update_text = 2131165200;
        public static final int common_google_play_services_update_title = 2131165198;
        public static final int common_google_play_services_updating_text = 2131165203;
        public static final int common_google_play_services_updating_title = 2131165202;
        public static final int common_open_on_phone = 2131165212;
        public static final int common_signin_button_text = 2131165216;
        public static final int common_signin_button_text_long = 2131165217;
        public static final int create_calendar_message = 2131165223;
        public static final int create_calendar_title = 2131165222;
        public static final int decline = 2131165221;
        public static final int gameservices_app_misconfigured = 2131165232;
        public static final int gameservices_license_failed = 2131165233;
        public static final int gameservices_sign_in_failed = 2131165231;
        public static final int lunar_console_log_details_dialog_button_copy_to_clipboard = 2131165237;
        public static final int lunar_console_log_details_dialog_no_stacktrace_warning = 2131165238;
        public static final int lunar_console_overflow_warning_text = 2131165239;
        public static final int lunar_console_title_fake_status_bar = 2131165240;
        public static final int np_toolbar_back = 2131165227;
        public static final int np_toolbar_done = 2131165230;
        public static final int np_toolbar_forward = 2131165228;
        public static final int np_toolbar_reload = 2131165229;
        public static final int store_picture_message = 2131165219;
        public static final int store_picture_title = 2131165218;
        public static final int upsight_sdk_build = 2131165234;
        public static final int upsight_sdk_version = 2131165235;
    }

    /* renamed from: rx.android.R.style */
    public static final class style {
        public static final int AppBaseTheme = 2131361793;
        public static final int AppTheme = 2131361794;
        public static final int FloatingActivityTheme = 2131361795;
        public static final int Theme_DeviceDefault_Light_Dialog_NoActionBar_UpsightDialog = 2131361796;
        public static final int Theme_IAPTheme = 2131361792;
        public static final int UnityThemeSelector = 2131361805;
        public static final int lunar_console_base_button_style = 2131361797;
        public static final int lunar_console_base_text_style = 2131361798;
        public static final int lunar_console_fake_status_bar_style = 2131361799;
        public static final int lunar_console_filter_edit_text_style = 2131361800;
        public static final int lunar_console_log_button_style = 2131361801;
        public static final int lunar_console_log_details_message_style = 2131361802;
        public static final int lunar_console_log_details_stacktrace_style = 2131361803;
        public static final int lunar_console_log_entry_message_style = 2131361804;
    }

    /* renamed from: rx.android.R.styleable */
    public static final class styleable {
        public static final int[] AdsAttrs;
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int[] LoadingImageView;
        public static final int LoadingImageView_circleCrop = 2;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 0;

        static {
            AdsAttrs = new int[]{C1518R.attr.adSize, C1518R.attr.adSizes, C1518R.attr.adUnitId};
            LoadingImageView = new int[]{C1518R.attr.imageAspectRatioAdjust, C1518R.attr.imageAspectRatio, C1518R.attr.circleCrop};
        }
    }

    /* renamed from: rx.android.R.xml */
    public static final class xml {
        public static final int nativeplugins_file_paths = 2131034112;
    }
}
