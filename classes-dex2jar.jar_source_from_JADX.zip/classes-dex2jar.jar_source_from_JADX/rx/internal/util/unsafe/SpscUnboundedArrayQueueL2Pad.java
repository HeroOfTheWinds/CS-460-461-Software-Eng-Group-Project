package rx.internal.util.unsafe;

abstract class SpscUnboundedArrayQueueL2Pad<E> extends SpscUnboundedArrayQueueProducerColdFields<E> {
    long p0;
    long p1;
    long p10;
    long p11;
    long p12;
    long p2;
    long p3;
    long p4;
    long p5;
    long p6;
    long p7;
    long p8;
    long p9;

    SpscUnboundedArrayQueueL2Pad() {
    }
}
