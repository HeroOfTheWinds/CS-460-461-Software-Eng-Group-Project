package dagger.internal;

import javax.inject.Provider;

public interface Factory<T> extends Provider<T> {
}
