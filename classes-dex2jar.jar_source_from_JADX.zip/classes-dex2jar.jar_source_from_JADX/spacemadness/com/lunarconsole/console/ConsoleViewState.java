package spacemadness.com.lunarconsole.console;

class ConsoleViewState {
    public static boolean scrollLocked;

    static {
        scrollLocked = true;
    }

    ConsoleViewState() {
    }
}
