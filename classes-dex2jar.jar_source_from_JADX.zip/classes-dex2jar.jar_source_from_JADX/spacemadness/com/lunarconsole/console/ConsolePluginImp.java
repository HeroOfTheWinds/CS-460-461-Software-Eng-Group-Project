package spacemadness.com.lunarconsole.console;

import android.view.View;

interface ConsolePluginImp {
    View getTouchRecepientView();
}
