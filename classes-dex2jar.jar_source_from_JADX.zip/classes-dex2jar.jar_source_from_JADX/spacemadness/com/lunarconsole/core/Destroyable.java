package spacemadness.com.lunarconsole.core;

public interface Destroyable {
    void destroy();
}
