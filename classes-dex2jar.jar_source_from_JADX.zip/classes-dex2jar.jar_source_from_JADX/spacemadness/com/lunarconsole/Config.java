package spacemadness.com.lunarconsole;

public class Config {
    public static final boolean DEBUG = false;
}
