package spacemadness.com.lunarconsole.utils;

public class NotImplementedException extends RuntimeException {
}
